package koeait.g334.alchemistry;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {

    BaseAdapter adapter; // Выносим адаптер в поле класса

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        ListView lv = findViewById(R.id.invList);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        adapter = new BaseAdapter() {
            @Override
            public int getCount() { return AppData.inventory.size(); }
            @Override
            public Object getItem(int position) { return AppData.inventory.get(position); }
            @Override
            public long getItemId(int position) { return position; }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                LinearLayout layout = new LinearLayout(InventoryActivity.this);
                layout.setOrientation(LinearLayout.HORIZONTAL);
                layout.setPadding(20, 20, 20, 20);

                Item item = AppData.inventory.get(position);

                ImageView img = new ImageView(InventoryActivity.this);
                img.setImageResource(item.imageRes);
                img.setLayoutParams(new LinearLayout.LayoutParams(80, 80));
                img.setScaleType(ImageView.ScaleType.FIT_CENTER);

                TextView txt = new TextView(InventoryActivity.this);
                txt.setText(item.name + " x" + item.count);
                txt.setTextColor(Color.WHITE);
                txt.setTextSize(18);
                txt.setPadding(30, 0, 0, 0);

                layout.addView(img);
                layout.addView(txt);
                return layout;
            }
        };

        lv.setAdapter(adapter);

        lv.setOnItemClickListener((parent, view, position, id) -> {
            Item item = AppData.inventory.get(position);
            if (item.count <= 1) {
                AppData.inventory.remove(position);
                adapter.notifyDataSetChanged();
            } else {
                showDeleteDialog(item, position);
            }
        });
    } // Конец метода onCreate

    // Метод для вызова диалога (стоит СНАРУЖИ onCreate)
    private void showDeleteDialog(Item item, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Удалить предмет");
        builder.setMessage("Сколько единиц '" + item.name + "' удалить? (Всего: " + item.count + ")");

        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setText("1");
        builder.setView(input);

        builder.setPositiveButton("Удалить", (dialog, which) -> {
            String value = input.getText().toString();
            if (!value.isEmpty()) {
                int amount = Integer.parseInt(value);
                if (amount >= item.count) {
                    AppData.inventory.remove(position);
                    // Toast.makeText(this, "Предмет удален полностью", Toast.LENGTH_SHORT).show(); // УДАЛИ ЭТУ СТРОКУ
                } else {
                    item.count -= amount;
                    // Toast.makeText(this, "Удалено: " + amount + " ед.", Toast.LENGTH_SHORT).show(); // УДАЛИ ЭТУ СТРОКУ
                }
                adapter.notifyDataSetChanged();
            }
        });


        builder.setNegativeButton("Отмена", (dialog, which) -> dialog.cancel());
        builder.show();
    }
}
