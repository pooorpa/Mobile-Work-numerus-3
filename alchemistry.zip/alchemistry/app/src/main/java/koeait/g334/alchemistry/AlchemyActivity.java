package koeait.g334.alchemistry;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class AlchemyActivity extends AppCompatActivity {
    Spinner s1, s2;
    ArrayList<Item> ingredients;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alchemy);

        s1 = findViewById(R.id.spin1);
        s2 = findViewById(R.id.spin2);
        updateSpinners();

        findViewById(R.id.btnCraft).setOnClickListener(v -> craft());
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }

    void updateSpinners() {
        ingredients = new ArrayList<>();
        for (Item i : AppData.inventory) {
            if (!i.isPotion) ingredients.add(i);
        }

        // Создаем кастомный адаптер, чтобы принудительно выставить белый цвет текста
        ArrayAdapter<Item> ad = new ArrayAdapter<Item>(this, android.R.layout.simple_spinner_item, ingredients) {
            @Override
            public android.view.View getView(int position, android.view.View convertView, android.view.ViewGroup parent) {
                TextView v = (TextView) super.getView(position, convertView, parent);
                v.setTextColor(android.graphics.Color.WHITE); // Белый текст в закрытом списке
                return v;
            }

            @Override
            public android.view.View getDropDownView(int position, android.view.View convertView, android.view.ViewGroup parent) {
                TextView v = (TextView) super.getDropDownView(position, convertView, parent);
                v.setTextColor(android.graphics.Color.WHITE); // Белый текст в открытом списке
                v.setBackgroundColor(android.graphics.Color.BLACK); // Черный фон выпадающего списка
                return v;
            }
        };

        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s1.setAdapter(ad);
        s2.setAdapter(ad);
    }

    private boolean check(Item a, Item b, String n1, String n2) {
        // Метод возвращает true, если (Первый = Ингредиент1 И ВТОРОЙ = Ингредиент2)
        // ИЛИ наоборот (так как порядок выбора в списках не должен влиять на успех)
        return (a.name.equals(n1) && b.name.equals(n2)) || (a.name.equals(n2) && b.name.equals(n1));
    }

    void craft() {
        Item i1 = (Item) s1.getSelectedItem();
        Item i2 = (Item) s2.getSelectedItem();
        if (i1 == null || i2 == null) {
            Toast.makeText(this, "Нечего смешивать", Toast.LENGTH_SHORT).show();
            return;
        }

        // Если выбраны одинаковые предметы (как на твоем скриншоте)
        if (i1.name.equals(i2.name)) {
            Toast.makeText(this, "Ингредиенты не могут повторяться", Toast.LENGTH_SHORT).show();
            return;
        }
        // Запоминаем имена выбранных предметов перед крафтом
        String selectedName1 = i1.name;
        String selectedName2 = i2.name;

        String recipe = i1.name + i2.name;
        Item res = null;

        // Рецепты
        if (check(i1, i2, "Прах Вампира", "Яйцо Коруса")) res = new Item("Зелье Невидимости", R.drawable.pot1, 1, true);
        else if (check(i1, i2, "Алый Корень Нирна", "Чеснок")) res = new Item("Зелье Сопротивления Магии", R.drawable.pot2, 1, true);
        else if (check(i1, i2, "Серебристый Окунь", "Клык Саблезуба")) res = new Item("Зелье Восстановления Запаса Сил", R.drawable.pot3, 1, true);

        // Тратим ингредиенты
        i1.count--; i2.count--;
        if (i1.count <= 0) AppData.inventory.remove(i1);
        if (i2.count <= 0) AppData.inventory.remove(i2);

        if (res != null) {
            // Успешный рецепт
            AppData.addItem(res);
            Toast.makeText(this, "Успех: " + res.name, Toast.LENGTH_SHORT).show();
        } else {
            // Неизвестная комбинация
            // Создаем "Неизвестное зелье", ставим иконку любого зелья (например, pot1)
            // Четвертый параметр true означает, что это зелье (его нельзя использовать для крафта)
            Item unknownPotion = new Item("Неизвестное зелье", R.drawable.unknown, 1, true);

            AppData.addItem(unknownPotion);
            Toast.makeText(this, "Неизвестное зелье", Toast.LENGTH_SHORT).show();
        }


        // Обновляем списки и восстанавливаем выбор
        updateSpinnersWithSelection(selectedName1, selectedName2);
    }

    void updateSpinnersWithSelection(String name1, String name2) {
        ingredients = new ArrayList<>();
        for (Item i : AppData.inventory) if (!i.isPotion) ingredients.add(i);

        // Кастомный адаптер с принудительно белым цветом текста
        ArrayAdapter<Item> ad = new ArrayAdapter<Item>(this, android.R.layout.simple_spinner_item, ingredients) {
            @Override
            public android.view.View getView(int position, android.view.View convertView, android.view.ViewGroup parent) {
                TextView v = (TextView) super.getView(position, convertView, parent);
                v.setTextColor(android.graphics.Color.WHITE); // Белый текст в закрытом списке
                return v;
            }

            @Override
            public android.view.View getDropDownView(int position, android.view.View convertView, android.view.ViewGroup parent) {
                TextView v = (TextView) super.getDropDownView(position, convertView, parent);
                v.setTextColor(android.graphics.Color.WHITE); // Белый текст в открытом списке
                v.setBackgroundColor(android.graphics.Color.BLACK); // Черный фон выпадающего списка
                return v;
            }
        };

        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s1.setAdapter(ad);
        s2.setAdapter(ad);

        // Восстановление выбора
        for (int i = 0; i < ingredients.size(); i++) {
            if (ingredients.get(i).name.equals(name1)) s1.setSelection(i);
            if (ingredients.get(i).name.equals(name2)) s2.setSelection(i);
        }
    }


}
