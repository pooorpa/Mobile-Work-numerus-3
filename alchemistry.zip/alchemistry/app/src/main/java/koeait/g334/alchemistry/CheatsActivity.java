package koeait.g334.alchemistry;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class CheatsActivity extends AppCompatActivity {
    // Названия и ID твоих файлов из папки drawable
    String[] names = {"Алый Корень Нирна", "Прах Вампира", "Чеснок", "Яйцо Коруса", "Клык Саблезуба", "Серебристый Окунь"};
    int[] icons = {R.drawable.nirn, R.drawable.dust, R.drawable.garlic, R.drawable.egg, R.drawable.fang, R.drawable.fish};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cheats);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        LinearLayout container = findViewById(R.id.cheatContainer);
        EditText et = findViewById(R.id.editCount);

        for (int i = 0; i < names.length; i++) {
            final int index = i;

            // 1. Получаем иконку из ресурсов
            android.graphics.drawable.Drawable img = getResources().getDrawable(icons[i], null);

            // 2. Устанавливаем размер иконки (64x64 пикселя)
            // Если иконка кажется слишком маленькой, замени 64 на 100
            img.setBounds(0, 0, 64, 64);

            Button b = new Button(this);
            b.setText("  " + names[index]);
            b.setTextColor(android.graphics.Color.WHITE);

            // Делаем фон кнопки чуть заметным (полупрозрачный черный)
            b.setBackgroundColor(android.graphics.Color.parseColor("#66000000"));

            // 3. Устанавливаем нашу уменьшенную иконку СЛЕВА от текста
            b.setCompoundDrawables(img, null, null, null);

            // Добавляем отступы, чтобы текст не прилипал к краям
            b.setPadding(30, 20, 30, 20);

            // Настраиваем внешний вид (опционально)
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 10, 0, 10); // Отступы между кнопками
            b.setLayoutParams(params);

            b.setOnClickListener(v -> {
                String countStr = et.getText().toString();
                int c = countStr.isEmpty() ? 1 : Integer.parseInt(countStr);
                AppData.addItem(new Item(names[index], icons[index], c, false));
                // Toast.makeText(this, names[index] + " добавлен!", Toast.LENGTH_SHORT).show(); // УДАЛИ ЭТУ СТРОКУ
            });

            container.addView(b);
        }
    }
}
