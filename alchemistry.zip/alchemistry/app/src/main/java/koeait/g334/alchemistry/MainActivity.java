package koeait.g334.alchemistry;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnCheats).setOnClickListener(v -> startActivity(new Intent(this, CheatsActivity.class)));
        findViewById(R.id.btnInventory).setOnClickListener(v -> startActivity(new Intent(this, InventoryActivity.class)));
        findViewById(R.id.btnAlchemy).setOnClickListener(v -> startActivity(new Intent(this, AlchemyActivity.class)));
    }
}
