package koeait.g334.alchemistry;

import java.io.Serializable;
import java.util.ArrayList;

public class AppData {
    public static ArrayList<Item> inventory = new ArrayList<>();

    public static void addItem(Item newItem) {
        for (Item i : inventory) {
            // Теперь проверяем только совпадение имен
            // Если имя совпадает (будь то чеснок или зелье), увеличиваем счетчик
            if (i.name.equals(newItem.name)) {
                i.count += newItem.count;
                return;
            }
        }
        // Если такого предмета еще нет в списке — добавляем новый
        inventory.add(newItem);
    }

}

class Item implements Serializable {
    public String name;
    public int imageRes;
    public int count;
    public boolean isPotion;

    public Item(String name, int imageRes, int count, boolean isPotion) {
        this.name = name;
        this.imageRes = imageRes;
        this.count = count;
        this.isPotion = isPotion;
    }
    @Override
    public String toString() { return name + " (" + count + ")"; }
}
